from setuptools import setup

setup(
    name='tvdatafeed',
    version='1.0.3',
    packages=['tvDatafeed'],
    url='https://www.youtube.com/watch?v=qDrXmb2ZRjo',
    license='MIT License',
    author='@StreamAlpha',
    author_email='',
    description='TradingView historical data downloader'
)
