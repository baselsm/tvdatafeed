from .main import TvDatafeed, Interval

__version__ = "1.0.3"
